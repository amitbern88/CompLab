#pragma once
#include "Bulbasaur.h"
class Ivysaur :
	public Pokemon
{
public:
	Ivysaur();
	~Ivysaur();
};

