#include "Ivysaur.h"



Ivysaur::Ivysaur() : Pokemon(Pokemon::PokemonType::eEarth, 2)
{
}


Ivysaur::~Ivysaur()
{
}
