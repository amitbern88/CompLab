#include "ListNode.h"



ListNode::ListNode(ListNode* next, Pokemon* pokemon) : nextNode(next), data(pokemon)
{
}


ListNode::~ListNode()
{
}
