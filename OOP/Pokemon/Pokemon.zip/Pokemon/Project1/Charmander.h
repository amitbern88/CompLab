#pragma once
#include "Pokemon.h"
class Charmander :
	public Pokemon
{
public:
	Charmander();
	
	char* getName();

	~Charmander();
};

