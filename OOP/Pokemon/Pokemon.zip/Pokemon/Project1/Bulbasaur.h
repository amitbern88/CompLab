#pragma once
#include "Pokemon.h"
class Bulbasaur :
	public Pokemon
{
public:
	Bulbasaur();

	char* getName();

	~Bulbasaur();
};

